package model;

/**
 * Staff model — mirrors the staff table in the database.
 * We pass this object around the GUI so every panel knows
 * who is logged in (their staffId, name, role).
 *
 * KEY CONCEPT — Encapsulation:
 * All fields are private. Access is only through getters.
 * No setters except setRole() since a staff member's role
 * can be changed by an admin.
 */
public class Staff {

    private final int    staffId;
    private final String firstName;
    private final String lastName;
    private       String role;
    private final String phoneNumber;
    private final String userName;

    public Staff(int staffId, String firstName, String lastName,
                 String role, String phoneNumber, String userName) {
        this.staffId     = staffId;
        this.firstName   = firstName;
        this.lastName    = lastName;
        this.role        = role;
        this.phoneNumber = phoneNumber;
        this.userName    = userName;
    }

    // Getters
    public int    getStaffId()     { return staffId; }
    public String getFirstName()   { return firstName; }
    public String getLastName()    { return lastName; }
    public String getRole()        { return role; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getUserName()    { return userName; }
    public String getFullName()    { return firstName + " " + lastName; }

    // The one setter — role can be updated
    public void setRole(String role) { this.role = role; }

    @Override
    public String toString() {
        return getFullName() + " (" + role + ")";
    }
}
