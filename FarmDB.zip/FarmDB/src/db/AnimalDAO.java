package db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * AnimalDAO handles all SQL for the animals, cattle, sheep, poultry tables.
 *
 * KEY CONCEPT — Transactions:
 * Adding a Cattle record requires TWO inserts: one into `animals`
 * and one into `cattle`. We wrap both in a transaction so if the
 * second insert fails, the first is rolled back — keeping the DB clean.
 */
public class AnimalDAO {

    private final Connection conn;

    public AnimalDAO() {
        this.conn = DatabaseManager.getInstance().getConnection();
    }

    /**
     * Returns all animals as a list of Object[] rows for the JTable.
     * Each row: {tagNumber, animalType, breed, gender, status, dateRegistered}
     */
    public List<Object[]> getAllAnimals() {
        List<Object[]> rows = new ArrayList<>();
        String sql = "SELECT tagNumber, animalType, breed, gender, status, dateRegistered " +
                     "FROM animals ORDER BY dateRegistered DESC";

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                rows.add(new Object[]{
                    rs.getString("tagNumber"),
                    rs.getString("animalType"),
                    rs.getString("breed"),
                    rs.getString("gender"),
                    rs.getString("status"),
                    rs.getString("dateRegistered")
                });
            }
        } catch (SQLException e) {
            System.err.println("Error loading animals: " + e.getMessage());
        }
        return rows;
    }

    /**
     * Returns animals filtered by type and/or status.
     * Passing "All" for either parameter skips that filter.
     */
    public List<Object[]> getFilteredAnimals(String type, String status) {
        List<Object[]> rows = new ArrayList<>();

        StringBuilder sql = new StringBuilder(
            "SELECT tagNumber, animalType, breed, gender, status, dateRegistered FROM animals WHERE 1=1"
        );
        if (!type.equals("All"))   sql.append(" AND animalType = ?");
        if (!status.equals("All")) sql.append(" AND status = ?");
        sql.append(" ORDER BY dateRegistered DESC");

        try (PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
            int idx = 1;
            if (!type.equals("All"))   stmt.setString(idx++, type);
            if (!status.equals("All")) stmt.setString(idx,   status);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                rows.add(new Object[]{
                    rs.getString("tagNumber"),
                    rs.getString("animalType"),
                    rs.getString("breed"),
                    rs.getString("gender"),
                    rs.getString("status"),
                    rs.getString("dateRegistered")
                });
            }
        } catch (SQLException e) {
            System.err.println("Error filtering animals: " + e.getMessage());
        }
        return rows;
    }

    /**
     * Inserts a base animal row plus its type-specific row (cattle/sheep/poultry).
     * Uses a transaction so both inserts succeed or both are rolled back.
     */
    public boolean addAnimal(String tagNumber, String animalType, String breed,
                             String gender, String status, String dateRegistered) {
        String animalSql = "INSERT INTO animals (tagNumber, animalType, breed, gender, status, dateRegistered) " +
                           "VALUES (?, ?, ?, ?, ?, ?)";
        String typeSql;
        switch (animalType.toUpperCase()) {
            case "CATTLE":  typeSql = "INSERT INTO cattle (tagNumber) VALUES (?)";  break;
            case "SHEEP":   typeSql = "INSERT INTO sheep (tagNumber) VALUES (?)";   break;
            case "POULTRY": typeSql = "INSERT INTO poultry (tagNumber) VALUES (?)"; break;
            default: return false;
        }

        try {
            conn.setAutoCommit(false); // start transaction

            try (PreparedStatement s1 = conn.prepareStatement(animalSql);
                 PreparedStatement s2 = conn.prepareStatement(typeSql)) {

                s1.setString(1, tagNumber);
                s1.setString(2, animalType.toUpperCase());
                s1.setString(3, breed);
                s1.setString(4, gender);
                s1.setString(5, status.toUpperCase());
                s1.setString(6, dateRegistered);
                s1.executeUpdate();

                s2.setString(1, tagNumber);
                s2.executeUpdate();

                conn.commit(); // both succeeded — save permanently
                return true;
            } catch (SQLException e) {
                conn.rollback(); // something failed — undo everything
                System.err.println("Add animal failed, rolled back: " + e.getMessage());
                return false;
            }
        } catch (SQLException e) {
            System.err.println("Transaction error: " + e.getMessage());
            return false;
        } finally {
            try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
        }
    }

    /** Updates the status of an animal (e.g. Healthy → Sick). */
    public boolean updateStatus(String tagNumber, String newStatus) {
        String sql = "UPDATE animals SET status = ? WHERE tagNumber = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newStatus.toUpperCase());
            stmt.setString(2, tagNumber);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Update status failed: " + e.getMessage());
            return false;
        }
    }

    /** Returns summary counts for the dashboard metric cards. */
    public int countByStatus(String status) {
        String sql = "SELECT COUNT(*) FROM animals WHERE status = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status.toUpperCase());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Count error: " + e.getMessage());
        }
        return 0;
    }

    public int countAll() {
        String sql = "SELECT COUNT(*) FROM animals";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Count error: " + e.getMessage());
        }
        return 0;
    }
}
