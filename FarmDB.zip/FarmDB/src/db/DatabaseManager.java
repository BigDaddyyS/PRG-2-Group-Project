package db;

import java.sql.*;

/**
 * DatabaseManager handles all JDBC connections.
 *
 * PATTERN: Singleton — only ONE instance ever exists.
 * This prevents opening hundreds of connections accidentally.
 *
 * HOW TO USE FROM ANY PANEL:
 *   Connection conn = DatabaseManager.getInstance().getConnection();
 *
 * SETUP: Change DB_URL, DB_USER, DB_PASS to match your MySQL install.
 * Make sure mysql-connector-j.jar is in your project's lib/ folder
 * and added to IntelliJ under File → Project Structure → Libraries.
 */
public class DatabaseManager {

    // ── Change these three lines to match your MySQL setup ──
    private static final String DB_URL  = "jdbc:mysql://localhost:3306/green_pastures_farm";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "1234";  // your MySQL root password

    private static DatabaseManager instance;
    private Connection connection;

    /** Private constructor — nobody can call new DatabaseManager() */
    private DatabaseManager() {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            System.out.println("Database connected successfully.");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL Driver not found. Add mysql-connector-j.jar to your project.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /** Returns the single shared instance, creating it if needed. */
    public static DatabaseManager getInstance() {
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }

    public Connection getConnection() {
        return connection;
    }

    /**
     * Checks if the connection is alive and reconnects if needed.
     * Call this before any DB operation in a long-running app.
     */
    public boolean isConnected() {
        try {
            return connection != null && !connection.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }
}
