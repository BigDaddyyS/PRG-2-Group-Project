package db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** HealthDAO — all SQL for the health_records table. */
public class HealthDAO {

    private final Connection conn;

    public HealthDAO() {
        this.conn = DatabaseManager.getInstance().getConnection();
    }

    /**
     * Returns all health records joined with staff name and animal tag.
     * Each row: {recordId, tagNumber, diagnosis, treatment, medicineUsed, staffName, treatmentDate}
     */
    public List<Object[]> getAllRecords() {
        List<Object[]> rows = new ArrayList<>();
        String sql =
            "SELECT h.recordID, h.tagNumber, h.diagnosis, h.treatment, " +
            "       h.medicineUsed, CONCAT(s.firstName,' ',s.lastName) AS attendedBy, h.treatmentDate " +
            "FROM health_records h " +
            "JOIN staff s ON h.attendedBy = s.staffId " +
            "ORDER BY h.treatmentDate DESC";

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                rows.add(new Object[]{
                    rs.getInt("recordID"),
                    rs.getString("tagNumber"),
                    rs.getString("diagnosis"),
                    rs.getString("treatment"),
                    rs.getString("medicineUsed"),
                    rs.getString("attendedBy"),
                    rs.getString("treatmentDate")
                });
            }
        } catch (SQLException e) {
            System.err.println("Error loading health records: " + e.getMessage());
        }
        return rows;
    }

    /**
     * Inserts a new health record.
     * attendedBy is the staffId integer from the logged-in staff object.
     */
    public boolean addRecord(String tagNumber, String treatmentDate, String diagnosis,
                             String treatment, String medicineUsed, int attendedBy) {
        String sql =
            "INSERT INTO health_records (tagNumber, treatmentDate, diagnosis, treatment, medicineUsed, attendedBy) " +
            "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, tagNumber);
            stmt.setString(2, treatmentDate);
            stmt.setString(3, diagnosis);
            stmt.setString(4, treatment);
            stmt.setString(5, medicineUsed);
            stmt.setInt(6, attendedBy);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Add health record failed: " + e.getMessage());
            return false;
        }
    }

    /** Returns the 5 most recent records for the dashboard. */
    public List<Object[]> getRecentRecords(int limit) {
        List<Object[]> rows = new ArrayList<>();
        String sql =
            "SELECT h.tagNumber, a.animalType, h.treatment, " +
            "       CONCAT(s.firstName,' ',s.lastName) AS attendedBy, h.treatmentDate " +
            "FROM health_records h " +
            "JOIN staff s ON h.attendedBy = s.staffId " +
            "JOIN animals a ON h.tagNumber = a.tagNumber " +
            "ORDER BY h.treatmentDate DESC LIMIT ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, limit);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                rows.add(new Object[]{
                    rs.getString("tagNumber"),
                    rs.getString("animalType"),
                    rs.getString("treatment"),
                    rs.getString("attendedBy"),
                    rs.getString("treatmentDate")
                });
            }
        } catch (SQLException e) {
            System.err.println("Error loading recent records: " + e.getMessage());
        }
        return rows;
    }
}
