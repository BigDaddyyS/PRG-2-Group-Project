package db;

import model.Staff;
import java.sql.*;

/**
 * StaffDAO (Data Access Object) handles all SQL for the staff table.
 *
 * WHY A DAO?
 * We keep ALL SQL in these DAO classes so the GUI panels never
 * touch SQL directly. If the database changes, you only fix it here.
 *
 * KEY CONCEPT — PreparedStatement:
 * We ALWAYS use PreparedStatement instead of string concatenation.
 * String concat like "WHERE username='" + u + "'" is vulnerable to
 * SQL injection attacks. PreparedStatement uses ? placeholders and
 * handles escaping automatically and safely.
 */
public class StaffDAO {

    private final Connection conn;

    public StaffDAO() {
        this.conn = DatabaseManager.getInstance().getConnection();
    }

    /**
     * Checks username and password against the staff table.
     * Returns a Staff object if valid, null if not.
     *
     * IMPORTANT: Your schema stores plain-text passwords.
     * For better security, hash passwords with BCrypt before storing.
     */
    public Staff authenticate(String username, String password) {
        String sql = "SELECT * FROM staff WHERE userName = ? AND password = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Build and return a Staff object from the result row
                return new Staff(
                    rs.getInt("staffId"),
                    rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getString("role"),
                    rs.getString("phoneNumber"),
                    rs.getString("userName")
                );
            }
        } catch (SQLException e) {
            System.err.println("Authentication error: " + e.getMessage());
        }
        return null; // login failed
    }
}
