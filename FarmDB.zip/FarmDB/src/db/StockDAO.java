package db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** StockDAO — all SQL for the stock_items table. */
public class StockDAO {

    private final Connection conn;

    public StockDAO() {
        this.conn = DatabaseManager.getInstance().getConnection();
    }

    /** Returns all stock items. Each row: {itemId, name, category, quantity, unit, reorderLevel, lastUpdated, status} */
    public List<Object[]> getAllItems() {
        List<Object[]> rows = new ArrayList<>();
        String sql = "SELECT itemId, name, category, quantity, unit, reorderLevel, lastUpdated FROM stock_items";

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                double qty     = rs.getDouble("quantity");
                double reorder = rs.getDouble("reorderLevel");
                String status  = qty <= reorder ? "Low" : "OK";
                rows.add(new Object[]{
                    rs.getInt("itemId"),
                    rs.getString("name"),
                    rs.getString("category"),
                    qty,
                    rs.getString("unit"),
                    reorder,
                    rs.getString("lastUpdated"),
                    status
                });
            }
        } catch (SQLException e) {
            System.err.println("Error loading stock: " + e.getMessage());
        }
        return rows;
    }

    /** Inserts a new stock item. */
    public boolean addItem(String name, String category, double quantity,
                           String unit, double reorderLevel) {
        String sql = "INSERT INTO stock_items (name, category, quantity, unit, reorderLevel, lastUpdated) " +
                     "VALUES (?, ?, ?, ?, ?, CURDATE())";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setString(2, category);
            stmt.setDouble(3, quantity);
            stmt.setString(4, unit);
            stmt.setDouble(5, reorderLevel);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Add stock item failed: " + e.getMessage());
            return false;
        }
    }

    /** Updates the quantity of an existing item (used when restocking or using). */
    public boolean updateQuantity(int itemId, double newQuantity) {
        String sql = "UPDATE stock_items SET quantity = ?, lastUpdated = CURDATE() WHERE itemId = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDouble(1, newQuantity);
            stmt.setInt(2, itemId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Update quantity failed: " + e.getMessage());
            return false;
        }
    }

    /** Returns count of items currently below reorder level (for dashboard). */
    public int countLowStock() {
        String sql = "SELECT COUNT(*) FROM stock_items WHERE quantity <= reorderLevel";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Low stock count error: " + e.getMessage());
        }
        return 0;
    }
}
