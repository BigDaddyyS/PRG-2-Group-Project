package gui;

import db.AnimalDAO;
import db.HealthDAO;
import db.StockDAO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.time.LocalDate;
import java.util.List;

public class ReportPanel extends JPanel {

    public ReportPanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(250, 250, 248));
        setBorder(new EmptyBorder(20, 24, 20, 24));
        build();
    }

    private void build() {
        JLabel title = new JLabel("Reports");
        title.setFont(new Font("SansSerif", Font.BOLD, 16));
        title.setBorder(new EmptyBorder(0, 0, 16, 0));
        add(title, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(2, 2, 14, 14));
        grid.setOpaque(false);

        grid.add(reportCard("Farm status report",
            "Full livestock summary for the bank or vet", "farm_status"));
        grid.add(reportCard("Animal loss report",
            "Animals that died, were lost or stolen", "animal_loss"));
        grid.add(reportCard("Stock inventory report",
            "Current stock levels and low-stock alerts", "stock_inventory"));
        grid.add(reportCard("Health summary report",
            "All health records and treatments", "health_summary"));

        add(grid, BorderLayout.CENTER);
    }

    private JPanel reportCard(String name, String desc, String key) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 210)),
            new EmptyBorder(16, 16, 16, 16)
        ));
        JLabel cardTitle = new JLabel(name);
        cardTitle.setFont(new Font("SansSerif", Font.BOLD, 13));
        JLabel cardDesc = new JLabel("<html><body style='width:180px'>" + desc + "</body></html>");
        cardDesc.setFont(new Font("SansSerif", Font.PLAIN, 12));
        cardDesc.setForeground(Color.GRAY);

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setOpaque(false);
        top.add(cardTitle);
        top.add(Box.createVerticalStrut(4));
        top.add(cardDesc);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        btns.setOpaque(false);
        btns.setBorder(new EmptyBorder(10, 0, 0, 0));

        JButton csvBtn = new JButton("Export CSV");
        csvBtn.setFocusPainted(false);
        csvBtn.addActionListener(e -> exportCSV(key, name));

        btns.add(csvBtn);
        card.add(top,  BorderLayout.CENTER);
        card.add(btns, BorderLayout.SOUTH);
        return card;
    }

    /**
     * Exports real database data to a CSV file.
     * Each report type queries a different DAO.
     */
    private void exportCSV(String key, String reportName) {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File(key + "_" + LocalDate.now() + ".csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        File file = chooser.getSelectedFile();

        try (FileWriter w = new FileWriter(file)) {
            w.write("Green Pastures Farm – " + reportName + "\n");
            w.write("Generated: " + LocalDate.now() + "\n\n");

            if (key.equals("farm_status")) {
                w.write("Tag no.,Type,Breed,Gender,Status,Registered\n");
                AnimalDAO dao = new AnimalDAO();
                for (Object[] r : dao.getAllAnimals())
                    w.write(r[0]+","+r[1]+","+r[2]+","+r[3]+","+r[4]+","+r[5]+"\n");

            } else if (key.equals("animal_loss")) {
                w.write("Status,Count\n");
                AnimalDAO dao = new AnimalDAO();
                w.write("Died,"   + dao.countByStatus("DIED")   + "\n");
                w.write("Lost,"   + dao.countByStatus("LOST")   + "\n");
                w.write("Stolen," + dao.countByStatus("STOLEN") + "\n");

            } else if (key.equals("stock_inventory")) {
                w.write("Item,Category,Quantity,Unit,Reorder level,Status\n");
                StockDAO dao = new StockDAO();
                for (Object[] r : dao.getAllItems())
                    w.write(r[1]+","+r[2]+","+r[3]+","+r[4]+","+r[5]+","+r[7]+"\n");

            } else if (key.equals("health_summary")) {
                w.write("Record ID,Tag no.,Diagnosis,Treatment,Medicine,Attended by,Date\n");
                HealthDAO dao = new HealthDAO();
                for (Object[] r : dao.getAllRecords())
                    w.write(r[0]+","+r[1]+","+r[2]+","+r[3]+","+r[4]+","+r[5]+","+r[6]+"\n");
            }

            JOptionPane.showMessageDialog(this,
                "Saved to:\n" + file.getAbsolutePath(),
                "Export successful", JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                "Could not save file:\n" + ex.getMessage(),
                "Export error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
