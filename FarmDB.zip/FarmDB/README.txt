GREEN PASTURES FARM MANAGEMENT SYSTEM
======================================

SETUP INSTRUCTIONS
------------------

1. DOWNLOAD MYSQL CONNECTOR
   - Go to: https://dev.mysql.com/downloads/connector/j/
   - Download the "Platform Independent" ZIP
   - Extract it and find the file named: mysql-connector-j-X.X.X.jar
   - Rename it to exactly: mysql-connector-j.jar
   - Place it in this project's /lib/ folder

2. ADD THE JAR TO INTELLIJ
   - Open IntelliJ → File → Project Structure → Libraries
   - Click the + button → Java → navigate to lib/mysql-connector-j.jar → OK → Apply

3. SET UP THE DATABASE
   - Open MySQL Workbench (or any MySQL client)
   - Run the SQL script your team wrote (creates all the tables)
   - Make sure the INSERT for the admin staff member ran too

4. CONFIGURE YOUR DB PASSWORD
   - Open: src/db/DatabaseManager.java
   - Change DB_PASS = "root" to your actual MySQL root password
   - If your MySQL username is not "root", change DB_USER too

5. RUN THE PROJECT
   - Right-click src/Main.java → Run 'Main'
   - Login with username: admin  password: admin123

TROUBLESHOOTING
---------------
"Communications link failure"  → MySQL is not running. Start it in MySQL Workbench or Services.
"Access denied for user"       → Wrong password in DatabaseManager.java
"Table doesn't exist"          → Run the SQL script first
"Driver not found"             → mysql-connector-j.jar not added to libraries (Step 2)
